<?php
echo "<html>/n <head> <title>Group10 Art Store</title> </head> <body>";

echo "<p>This is a test</p>";

echo "</body>\n </html>";

?>
